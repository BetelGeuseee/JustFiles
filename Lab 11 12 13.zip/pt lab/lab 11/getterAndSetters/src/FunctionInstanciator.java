public class FunctionInstanciator {
    public static void main(String[] args){
        Second s1=new Second();
        s1.instanciate("kathmandu"); // instanciates instance variable str in second class
        s1.Display();
    }
}
class Second{
    String str;
    void instanciate(String a){
        str=a;
    }
    void Display(){
        System.out.println("String is: "+str);
    }
}
