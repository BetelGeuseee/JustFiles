package com.example.seismic;

import android.content.Context;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SaveEarthquake {
  //  private List<EarthquakeData> filteredList;
   // private FirebaseAuth auth;
    private FirebaseDatabase database;
    Context context;
    SaveEarthquake(Context context){
        this.database=FirebaseDatabase.getInstance();
        this.context=context;
      //  this.filteredList=new ArrayList<>();
    }
    public void saveEarthquakeData(List<EarthquakeData> earthquakeDataList,FirebaseAuth auth){

        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("dd MMMM yyyy");
        String strDate = formatter.format(date);
        database.getReference().child("EarthquakeData").child(strDate).setValue(earthquakeDataList).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Toast.makeText(context,"List uploaded Successfully",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
