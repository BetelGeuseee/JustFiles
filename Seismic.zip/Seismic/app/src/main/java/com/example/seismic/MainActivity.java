package com.example.seismic;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ListView listView;
    private MyAdapter myAdapter;
    private ProgressBar spinner;
    private FirebaseAuth auth;
    private FirebaseDatabase database;
    private final  static String USGS_REQUEST_URL="https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&orderby=time&minmag=3&limit=10";
    private class EarthquakeAsyncTask extends AsyncTask<String,View, List<EarthquakeData>>{
        FirebaseAuth mauth;
        public EarthquakeAsyncTask(FirebaseAuth auth){
            this.mauth=auth;
        }
        @Override
        protected List<EarthquakeData> doInBackground(String... urls) {
            /*
             * This method runs on a background thread and performs the network request.
             * We should not update the UI from a background thread, so we return a list of
             * {@link Earthquake}s as the result.
             */
           if(urls.length<1 || urls[0]==null){
               return null;
           }
           List<EarthquakeData> result =QueryUtils.fetchEarthquakeData(urls[0]);
           new SaveEarthquake(getApplicationContext()).saveEarthquakeData(result,mauth);
           return result;
        }
        /*
         * This method runs on the main UI thread after the background work has been
         * completed. This method receives as input, the return value from the doInBackground()
         * method. First we clear out the adapter, to get rid of earthquake data from a previous
         * query to USGS. Then we update the adapter with the new list of earthquakes,
         * which will trigger the ListView to re-populate its list items.
         */
        @Override
        protected void onPostExecute(List<EarthquakeData> earthquakeData) {
            //clear all the previous data from the adapter
            myAdapter.clear();
            // If there is a valid list of {@link Earthquake}s, then add them to the adapter's
                // data set. This will trigger the ListView to update.
                if (earthquakeData!= null && !earthquakeData.isEmpty()) {
                myAdapter.addAll(earthquakeData);
            }
            spinner.setVisibility(View.GONE);
        }

        @Override
        protected void onProgressUpdate(View... values) {
            spinner.setVisibility(View.VISIBLE);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView)findViewById(R.id.listerr);
        spinner=(ProgressBar)findViewById(R.id.progressBar1);
        auth=FirebaseAuth.getInstance();
        database=FirebaseDatabase.getInstance();
       myAdapter = new MyAdapter(this,new ArrayList<EarthquakeData>());
        listView.setAdapter(myAdapter);
        EarthquakeAsyncTask asyncTask = new EarthquakeAsyncTask(auth);
        asyncTask.execute(USGS_REQUEST_URL);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                EarthquakeData currentEarthquake = myAdapter.getItem(position);
                Uri earthquakeUri = Uri.parse(currentEarthquake.getUrls());
                Intent websiteIntent = new Intent(Intent.ACTION_VIEW,earthquakeUri);
                startActivity(websiteIntent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.top_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.load:
                /*ArrayList<String> dates = new ArrayList<>();
                database.getReference().child("EarthquakeData").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) { //this method is called asynchronously
                        dates.clear();
                        for(DataSnapshot postSnapshot : snapshot.getChildren()){
                            String date= postSnapshot.getKey();
                           // Toast.makeText(DateEvent.this,date,Toast.LENGTH_SHORT).show();
                            dates.add(date);
                        }
                        // Toast.makeText(DateEvent.this,dates.get(0),Toast.LENGTH_SHORT).show();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                       // Toast.makeText(DateEvent.this,error.getMessage(),Toast.LENGTH_SHORT).show();
                    }
                }); */
                Intent intent = new Intent(MainActivity.this,DateEvent.class);
               // intent.putExtra("quakeDate",dates);
                startActivity(intent);
                Toast.makeText(MainActivity.this,"Load Clicked",Toast.LENGTH_SHORT).show();
                break;
            case R.id.logout:
                auth.signOut();
                Intent intents = new Intent(MainActivity.this, SignInActivity.class);
                startActivity(intents);
                finish();
                break;
        }
        return true;
    }
}