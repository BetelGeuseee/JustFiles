package Servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "LoginAndLoadDashboardServlet", value = "/LoginAndLoadDashboardServlet")
public class LoginAndLoadDashboardServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Give the value from Text Field not the field
        String UserID= request.getParameter("UserID");
        System.out.println(UserID);

        //Give the value from password field not the field
        String Pass=request.getParameter("Password");
        System.out.println(Pass);

        if(UserID.equals("admin") ){
            System.out.println("inside");
//            response.sendRedirect("./WEB-INF/Dashboard");
            RequestDispatcher view=request.getRequestDispatcher("./WEB-INF/Dashboard.jsp");
            view.forward(request,response);
        }
    }
}
