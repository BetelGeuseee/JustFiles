public class Constructor_overloader {
    public static void main( String[] args){
        System.out.println("Hello, world!");

        Contains_constructors obj1= new Contains_constructors();
        obj1.Display();
        Contains_constructors obj2= new Contains_constructors("laxman");
        obj2.Display();
        Contains_constructors obj3= new Contains_constructors("laxman","pokhrel");
        obj3.Display();
        Contains_constructors obj4= new Contains_constructors("laxman", "pokhrel",1813118);
        obj4.Display();
    }
}
class Contains_constructors{
    String Name;
    String Adress;
    int rollnumber;
    Contains_constructors(){  //Default Constructor
        Name="Ram lal Yadav";
        Adress="Mahotari";
        rollnumber=23;
    }
    Contains_constructors(String a){ // Overloaded with one parameter
        Name=a;
        Adress="NOT SET";
        rollnumber=0;
    }
    Contains_constructors(String a, String b){  // Overloaded with two parameters
        Name=a;
        Adress=b;
        rollnumber=0;
    }
    Contains_constructors(String a, String b, int c){ // Overloaded with three parameters
        Name=a;
        Adress=b;
        rollnumber=c;
    }
    void Display()
    {
        System.out.println("Name is: "+Name);
        System.out.println("Address is: "+Adress);
        System.out.println("Roll Number is: "+rollnumber);
        System.out.println("-----------------------------------------");
    }
}
