package com.example.seismic;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class DisplayEarthquakes extends AppCompatActivity {

    FirebaseDatabase database;
    ArrayList<EarthquakeData> quakes;
    ListView viewList;
    MyAdapter myAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_earthquakes);
        database=FirebaseDatabase.getInstance();
        viewList=(ListView)findViewById(R.id.listtt);
        String issueDate=getIntent().getStringExtra("dateValue");
        quakes=new ArrayList<>();
        myAdapter=new MyAdapter(this,quakes);
        viewList.setAdapter(myAdapter);
        database.getReference().child("EarthquakeData").child(issueDate).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                quakes.clear();
                for(DataSnapshot postSnapshot : snapshot.getChildren()){
                    EarthquakeData eqData = postSnapshot.getValue(EarthquakeData.class);
                    quakes.add(eqData);
                   // Toast.makeText(DisplayEarthquakes.this,quakes.size(),Toast.LENGTH_SHORT).show();
                }
                myAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}