package com.example.seismic;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {

    Button signIn,register;
    EditText userName,eMail,passWord;
    FirebaseAuth auth;
    FirebaseDatabase database;
    ProgressDialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_register);
        getSupportActionBar().hide();
        register=(Button)findViewById(R.id.registerBtn);
        signIn=(Button)findViewById(R.id.signInBtn);
        userName=(EditText)findViewById(R.id.username);
        eMail=(EditText)findViewById(R.id.email);
        passWord=(EditText)findViewById(R.id.password);
        auth=FirebaseAuth.getInstance();
        database=FirebaseDatabase.getInstance();
        dialog= new ProgressDialog(this);
        dialog.setTitle("Authentication");
        dialog.setMessage("Authenticating....");
        dialog.setCancelable(false);
        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this,SignInActivity.class);
                startActivity(intent);
                finish();
            }
        });
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if(userName.getText().toString().isEmpty() || eMail.getText().toString().isEmpty() || passWord.getText().toString().isEmpty()){
                   Toast.makeText(RegisterActivity.this,"Please Enter some text",Toast.LENGTH_SHORT).show();
               }else{
                   registerAccount(eMail.getText().toString(),passWord.getText().toString(),userName.getText().toString());
               }
            }
        });
    }
    public void registerAccount(String email,String password,String username){
        auth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    dialog.show();
                    String uid=auth.getUid();
                    UserModel users = new UserModel(userName.getText().toString(),eMail.getText().toString(),uid);
                    database.getReference().child("Users").child(uid).setValue(users).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(RegisterActivity.this,"Account Created Successfully",Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                            Intent intent  = new Intent(RegisterActivity.this,SignInActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    });

                }else{
                    Toast.makeText(RegisterActivity.this,"Cannot create account",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}