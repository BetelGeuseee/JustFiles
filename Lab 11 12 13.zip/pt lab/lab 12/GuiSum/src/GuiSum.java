import javax.swing.JOptionPane;

public class GuiSum {
    public static void main(String[] args) {
        String FirstNumber = JOptionPane.showInputDialog("Enter 1st Number");
        String SecondNumber = JOptionPane.showInputDialog("Enter 2st Number");
        //to parse the input into integer
        int Num1 = Integer.parseInt(FirstNumber);
        int Num2 = Integer.parseInt(SecondNumber);
        int sum = Num1 + Num2;
        JOptionPane.showMessageDialog(null, "The Sum is " + sum, "Sum of Two Integer:", JOptionPane.INFORMATION_MESSAGE);
    }

}
//Laxman Pohrel






