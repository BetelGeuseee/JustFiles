import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ClickCounter  implements ActionListener {
    int counter =0;
    JFrame frame;
    //JPanel panel;
    JButton button;
    JLabel label;
        ClickCounter(){


            frame=new JFrame();
            frame.setTitle("Click Counter");
            frame.setSize(250,250);

            JPanel  panel=new JPanel();
            panel.setLayout(null);
            frame.add(panel);

            //click counter Title
            Label CounterTitle=new Label("Hi!, I Can Count Your Clicks.");
            CounterTitle.setSize(500,50);
            CounterTitle.setLocation(new Point(10,10));
            CounterTitle.setFont(new Font("Verdana", Font.BOLD, 16));
            panel.add(CounterTitle);


            label=new JLabel();
            label.setText("Number of clicks: 0");
            label.setSize(150,50);
            label.setLocation(new Point(50,50));
            panel.add(label);

            button=new JButton();
            button.setText("Click Me");
            button.setSize(100,30);
            button.setLocation(new Point(50,100));
            panel.add(button);
            button.addActionListener(this);
            frame.setVisible(true);

        }


    public static void main(String[] args) {

            new ClickCounter();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    counter++;
    label.setText("Number of Clicks: "+counter);
    }
}
