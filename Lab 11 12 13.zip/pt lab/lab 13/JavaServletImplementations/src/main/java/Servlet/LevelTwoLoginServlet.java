package Servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "LevelTwoLoginServlet", value = "/LevelTwoLoginServlet")
public class LevelTwoLoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //it shows the parameters passed to this servlet in the URL (...?Parameter1_name=value&Parameter2_name=value2...)
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //this method doesnot show thw parameters passed to this servlet in the URL...
       //get the values from the form
        String UserId=request.getParameter("UserID");
        String pass=request.getParameter("Password");
        //to store the error
        StringBuilder error=new StringBuilder();
        if(UserId.isEmpty()){
            error.append("UserID not provided.");
        }else if(pass.isEmpty()){
            error.append("password not provided");
        }
        if(error.length()>0){
            System.out.println("From Level2Servlet");
            request.setAttribute("error",error.toString());
            getServletContext().getRequestDispatcher("/LevelTwoLoginForm.jsp").forward(request,response);
        }else{
            request.setAttribute("User",UserId);
            request.setAttribute("Password",pass);
            System.out.println("From Level2Servlet");
            getServletContext().getRequestDispatcher("/CallerServlet").forward(request,response);
        }
    }
}
