public class InnerClass {
    public static void main(String[] args){
        Outer out=new Outer();
        out.displayOuter();
        Outer.Inner in=out.new Inner();
        in.displayInner();
    }

}
class Outer{
    void displayOuter(){
        System.out.println("I am from outer Class");
    }


    class Inner{   // class inside Outer class
        void displayInner(){
            System.out.println("I am from Inner Class");
        }
    }
}
