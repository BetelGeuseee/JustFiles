import javax.swing.*;

public class TestForm {
    private JButton button1;
    private JPanel panel1;
}
