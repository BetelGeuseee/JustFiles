package Servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "CallerServlet", value = "/CallerServlet")
public class CallerServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("From caller Servlet");
        //get the attributes set by the leveltwologinservlet
        String s=(String)request.getAttribute("User");
        String p=(String)request.getAttribute("Password");
        System.out.println(s);
        System.out.println(p);
        getServletContext().getRequestDispatcher("/WEB-INF/Level2Dashboard.jsp").forward(request,response);
    }
}
