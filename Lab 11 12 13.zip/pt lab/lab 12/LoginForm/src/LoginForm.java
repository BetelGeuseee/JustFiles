import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginForm extends JFrame implements ActionListener {
    JFrame LoginForm;
    JPanel Panel;
    JLabel UserText;
    JLabel Password;
    JTextField ID;
    JPasswordField Code;
    JButton SubmitButton;
    JLabel Success;

    LoginForm() {
        LoginForm = new JFrame("Login Form");
        LoginForm.setSize(400, 400);
        LoginForm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Panel = new JPanel();
        Panel.setLayout(null);
        LoginForm.add(Panel);

        UserText = new JLabel("Uset ID");
        UserText.setBounds(20, 20, 50, 15);
        Panel.add(UserText);

        Password = new JLabel("Password");
        Password.setBounds(20, 60, 100, 15);
        Panel.add(Password);

        ID = new JTextField();
        ID.setBounds(150, 20, 200, 20);
        Panel.add(ID);

        Code = new JPasswordField();
        Code.setBounds(150, 60, 200, 20);
        Panel.add(Code);

        SubmitButton = new JButton("Login");
        SubmitButton.setBounds(50, 120, 80, 30);
        SubmitButton.addActionListener(this);
        Panel.add(SubmitButton);

        Success = new JLabel();
        Success.setBounds(50, 200, 200, 25);
        Panel.add(Success);


        LoginForm.setVisible(true);
    }

    public static void main(String[] args) {
        new LoginForm();

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String User = ID.getText();
        String Passcode = Code.getText();

        if (User.equals("admin") && Passcode.equals("pass")) {
            Success.setText("Login Successful");
        }
    }
}
