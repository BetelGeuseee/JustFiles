public class Method_overload {
    public static void main(String[] args){
        System.out.println("hello world");
       SecondClass sc1=new SecondClass();
       sc1.sum(34,56);
       sc1.sum(50,56,9876);
    }
}
class SecondClass{
    int a ;
    int b;
    int c;
    void sum(int num1,int num2){
        int s=num1+num2;
        System.out.println("sum is: "+s);
        System.out.println("-------------");
    }
    void sum(int num1,int num2,int num3){//overloading function with three arguments
        int s=num1+num2+num3;
        System.out.println("sum is: "+s);
    }

}
