public class Inheritance {
    public static void main(String[] args){
        Car BMW=new Car(); // creating child class object
        BMW.carDisplay();
        BMW.display();
    }
}
class Transport{
    void display(){
        System.out.println("I an TRANSPORT");
    }
}
class Car extends Transport{ //Car is Inherited from transport
    void carDisplay(){
        System.out.println("i am from Car");
    }
}