package com.example.seismic;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class DateEvent extends AppCompatActivity {

    FirebaseAuth auth;
    FirebaseDatabase database;
   ArrayList<String> dates;
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date_event);
        auth=FirebaseAuth.getInstance();
        database=FirebaseDatabase.getInstance();
        listView=(ListView)findViewById(R.id.listview);
       // ArrayList<String> earthquakeDates= (ArrayList<String>) getIntent().getSerializableExtra("quakeDate");
        dates=new ArrayList<>();
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,
                dates);
        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String value =(String)parent.getItemAtPosition(position);
                //Toast.makeText(DateEvent.this,value,Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(DateEvent.this,DisplayEarthquakes.class);
                intent.putExtra("dateValue",value);
                startActivity(intent);
            }
        });
       database.getReference().child("EarthquakeData").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) { //this method is called asynchronously
                dates.clear();
                for(DataSnapshot postSnapshot : snapshot.getChildren()){
                    String date= postSnapshot.getKey();
                  //  Toast.makeText(DateEvent.this,date,Toast.LENGTH_SHORT).show();
                    dates.add(date);
                }
                arrayAdapter.notifyDataSetChanged(); //without this the data will not show.
               // Toast.makeText(DateEvent.this,dates.get(0),Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(DateEvent.this,error.getMessage(),Toast.LENGTH_SHORT).show();
            }

        });

    }
}