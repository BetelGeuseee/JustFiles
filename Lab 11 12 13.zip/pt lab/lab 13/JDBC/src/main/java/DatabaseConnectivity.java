import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class DatabaseConnectivity {
    public String userName = "root";
    public String password = "laxudb";
    public String databaseName = "ncitDB";
    /*Database Url for MySQL*/
    public String databaseUrl = "jdbc:mysql://localhost:3360/ncitDB";
    /*Database Url for MS Access*/
    //"jdbc:odbc:ncitDB";
    /*Database Url for Oracle*/
    //"jdbc:oracle:thin:@localhost:3306:ncitDB";

    public static void main(String[] args) {
        DatabaseConnectivity dbCon = new DatabaseConnectivity();
        Connection con = null;
        try {
            /*Load Driver MySQL*/
            Class.forName("com.mysql.cj.jdbc.Driver");

            /*Load Driver MS Access*/
            //Class.forName("sun.jdbc.odbc.JdbcOdbcDriver").newInstance();

            //Database Connection
            con = DriverManager.getConnection(dbCon.databaseUrl, dbCon.userName,
                    dbCon.password);

            /*SELECT*/
            Statement stmt = con.createStatement();
            ResultSet rst = stmt.executeQuery("SELECT * FROM tblStudent");
            System.out.println("Roll Number: \t\t Name:");

            while(rst.next()){
                //String rollNumber = rst.getString(1);
                //String name = rst.getString(2);
                String rollNumber = rst.getString("Roll");
                String name = rst.getString("Name");
                System.out.println(rollNumber +"\t\t\t"+name);
            }

        }catch(Exception exp){
            System.out.println("Message: "+exp.getMessage());
            exp.printStackTrace();
        } finally {
            try {
                con.close();
            }catch(Exception e){

            }
        }
    }
}
